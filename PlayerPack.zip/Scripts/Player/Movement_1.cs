using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class Movement_1 : MonoBehaviour
{
    public GameObject Model;
    public GameObject Camera;
    public GameObject ViewModel;
    public int WalkSpeed;
    public int RunSpeed;
    float roty = 0.0f;
    public bool Sprinting;
    public Transform pivotTransform;
    // Start is called before the first frame update
    void Start()
    {
        Camera.transform.localRotation = Quaternion.Euler(0, 0, 0);
        Cursor.lockState = CursorLockMode.Locked;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey("left shift"))
        {
            Sprinting = true;
        }
        else
        {
            Sprinting = false;
        }

        if (Sprinting == true)
        {
            transform.Translate(Input.GetAxis("Horizontal") * Time.deltaTime * RunSpeed, 0, Input.GetAxis("Vertical") * Time.deltaTime * RunSpeed);
        }
        else
        {
            transform.Translate(Input.GetAxis("Horizontal") * Time.deltaTime * WalkSpeed, 0, Input.GetAxis("Vertical") * Time.deltaTime * WalkSpeed);
        }
        roty += 2.0f * Input.GetAxis("Mouse Y");
       roty = Mathf.Clamp(roty, -90f, 90f);
        Camera.transform.localRotation = Quaternion.Euler(roty, 0f, 0f);
        transform.Rotate(0, Input.GetAxis("Mouse X"), 0);

    }
}
